new Chart(document.getElementById("line-chart"), {
  type: 'line',
  data: {
    labels: [2005,2008,2014,2015,2016],
    datasets: [{ 
        data: [400,450,230,240,279],
        label: "Groningen",
        borderColor: "#3e95cd",
        fill: false
      }, { 
        data: [500,352,280,290,308],
        label: "Friesland",
        borderColor: "#8e5ea2",
        fill: false
      }, { 
        data: [600,129,180,200,231],
        label: "Drenthe",
        borderColor: "#3cba9f",
        fill: false
      }, { 
        data: [900,200,800,1050,1390],
        label: "Noord Holland",
        borderColor: "#e8c3b9",
        fill: false
      }, { 
        data: [850,500,1000,850,1726],
        label: "Zuid Holland",
        borderColor: "#c45850",
        fill: false
      }
    ]
  },
  options: {
    title: {
      display: true,
      text: 'Arbeidsdeelname per regio'
    }
  }
});